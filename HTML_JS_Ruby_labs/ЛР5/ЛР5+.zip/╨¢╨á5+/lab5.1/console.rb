# frozen_string_literal: true

require_relative 'main'
print 'x: '
x_num = gets.to_f
print 'y: '
y_num = gets.to_f
puts "Result: #{maths x_num, y_num}"
